let hours_worked = [30; 45 ; 33; 25]
