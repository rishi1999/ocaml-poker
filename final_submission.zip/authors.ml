let hours_worked = [-1; 38 ; 33; -1]
